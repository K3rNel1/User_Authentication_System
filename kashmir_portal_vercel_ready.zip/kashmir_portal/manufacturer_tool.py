"""
manufacturer_tool.py — Kashmir Authenticity Portal
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Desktop GUI for manufacturers to upload product serial numbers.

What it does:
  • Browse and load an Excel (.xlsx / .xls) or CSV file
  • Preview rows before importing
  • Bulk-import serial numbers directly into Supabase
  • View and delete existing records

Requirements:
    pip install supabase python-dotenv pandas openpyxl
    (tkinter is included with standard Python on Windows / macOS / Linux)

Run:
    python manufacturer_tool.py
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime

# database.py must sit in the same folder as this file
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

try:
    import database as db
except EnvironmentError as e:
    # database.py raises EnvironmentError when .env is missing
    messagebox.showerror("Configuration Error", str(e))
    sys.exit(1)
except ImportError:
    messagebox.showerror("Missing file", "database.py must be in the same folder as this tool.")
    sys.exit(1)

try:
    import pandas as pd
except ImportError:
    messagebox.showerror(
        "Missing library",
        "Please install the required libraries first:\n\n"
        "    pip install pandas openpyxl supabase python-dotenv\n\n"
        "Then re-run this tool."
    )
    sys.exit(1)


# ──────────────────────────────────────────────────────────────────────────────
# Column name aliases — recognises many header variations from manufacturer sheets
# ──────────────────────────────────────────────────────────────────────────────
COL_MAP = {
    # serial number
    "serial":           "serial_number",
    "serial number":    "serial_number",
    "serialnumber":     "serial_number",
    "serial_number":    "serial_number",
    "sn":               "serial_number",
    "s/n":              "serial_number",
    "barcode":          "serial_number",
    # product name
    "product":          "product_name",
    "product name":     "product_name",
    "productname":      "product_name",
    "product_name":     "product_name",
    "name":             "product_name",
    "item":             "product_name",
    "item name":        "product_name",
    # artisan
    "artisan":          "artisan",
    "maker":            "artisan",
    "craftsman":        "artisan",
    "weaver":           "artisan",
    # craft tradition
    "craft":            "craft",
    "tradition":        "craft",
    "craft type":       "craft",
    # region / origin
    "region":           "region",
    "origin":           "region",
    "location":         "region",
    "place":            "region",
    # material
    "material":         "material",
    "materials":        "material",
    "fabric":           "material",
    # category
    "category":         "category",
    "type":             "category",
    # GI tag
    "gi":               "gi_tag",
    "gi tag":           "gi_tag",
    "gi_tag":           "gi_tag",
    # registration date
    "registered":       "registered_on",
    "date":             "registered_on",
    "registered on":    "registered_on",
    "registered_on":    "registered_on",
}

REQUIRED_COLS = {"serial_number", "product_name"}

# ── Kashmir-inspired colour palette ──────────────────────────────────────────
BG        = "#f7f2eb"
CARD      = "#ffffff"
GOLD      = "#8a5c1a"
GOLD_DARK = "#5c3a0d"
GOLD_LITE = "#d4a96a"
TEXT      = "#2c1f0e"
TEXT_MUTE = "#a0845a"
GREEN     = "#2d6a2d"
RED_DARK  = "#7a3020"
BORDER    = "#d4b896"

FONT_HEAD = ("Georgia", 16, "bold")
FONT_BODY = ("Georgia", 11)
FONT_MONO = ("Courier New", 10)
FONT_BTN  = ("Georgia", 10)
FONT_TINY = ("Georgia", 9)


# ══════════════════════════════════════════════════════════════════════════════
class ManufacturerApp(tk.Tk):
# ══════════════════════════════════════════════════════════════════════════════

    def __init__(self):
        super().__init__()
        self.title("Kashmir Authenticity Portal — Manufacturer Tool")
        self.geometry("1100x750")
        self.minsize(900, 600)
        self.configure(bg=BG)
        self.resizable(True, True)

        self._preview_df   = None  # DataFrame from the loaded Excel/CSV
        self._current_file = None  # path to the currently loaded file

        self._build_ui()
        self._refresh_db_tab()

    # ─── UI layout ────────────────────────────────────────────────────────────

    def _build_ui(self):
        # Header bar
        header = tk.Frame(self, bg=GOLD_DARK, pady=14)
        header.pack(fill="x")
        tk.Label(
            header,
            text="Kashmir Authenticity Portal",
            font=("Georgia", 18, "bold"),
            fg="#fdf8f2", bg=GOLD_DARK
        ).pack()
        tk.Label(
            header,
            text="MANUFACTURER PRODUCT REGISTRATION TOOL",
            font=("Georgia", 9),
            fg=GOLD_LITE, bg=GOLD_DARK
        ).pack()

        # Style the notebook
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook",        background=BG, borderwidth=0)
        style.configure("TNotebook.Tab",    background=BORDER, foreground=TEXT,
                        font=FONT_BTN, padding=[14, 6])
        style.map("TNotebook.Tab",
                  background=[("selected", GOLD)],
                  foreground=[("selected", "#fdf8f2")])
        style.configure("Treeview",         background=CARD, foreground=TEXT,
                        fieldbackground=CARD, rowheight=24, font=FONT_TINY)
        style.configure("Treeview.Heading", background=BORDER, foreground=GOLD_DARK,
                        font=("Georgia", 9, "bold"))
        style.map("Treeview",               background=[("selected", GOLD_LITE)])

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=16, pady=12)

        tab_import = ttk.Frame(notebook)
        tab_db     = ttk.Frame(notebook)
        notebook.add(tab_import, text="  ① Import from Excel  ")
        notebook.add(tab_db,     text="  ② Database Records  ")
        notebook.bind("<<NotebookTabChanged>>", lambda _: self._refresh_db_tab())

        self._build_import_tab(tab_import)
        self._build_db_tab(tab_db)

    # ─── Tab 1: Import from Excel ─────────────────────────────────────────────

    def _build_import_tab(self, parent):
        # Step 1 — choose file
        step1 = self._section(parent, "Step 1 — Select Excel or CSV File")
        step1.pack(fill="x", padx=20, pady=(16, 8))

        file_row = tk.Frame(step1, bg=CARD)
        file_row.pack(fill="x", padx=16, pady=12)

        self._file_var = tk.StringVar(value="No file selected")
        tk.Label(
            file_row, textvariable=self._file_var,
            font=FONT_MONO, bg=CARD, fg=TEXT_MUTE, anchor="w"
        ).pack(side="left", fill="x", expand=True)
        self._btn(file_row, "Browse…", self._browse_file, side="right")

        hint = (
            "Expected columns (any order, flexible names accepted): "
            "serial_number  product_name  artisan  craft  region  material  category  [registered_on]"
        )
        tk.Label(
            step1, text=hint, font=FONT_TINY, bg=CARD, fg=TEXT_MUTE,
            wraplength=700, justify="left"
        ).pack(anchor="w", padx=16, pady=(0, 10))

        # Step 2 — preview
        step2 = self._section(parent, "Step 2 — Preview (first 50 rows)")
        step2.pack(fill="both", expand=True, padx=20, pady=8)

        tree_frame = tk.Frame(step2, bg=CARD)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=8)

        self._prev_tree = self._make_treeview(tree_frame, [])
        self._prev_tree.pack(fill="both", expand=True)

        # Status + import button
        bottom = tk.Frame(parent, bg=BG)
        bottom.pack(fill="x", padx=20, pady=(4, 12))

        self._preview_status = tk.Label(
            bottom, text="", font=FONT_TINY, bg=BG, fg=TEXT_MUTE, anchor="w"
        )
        self._preview_status.pack(side="left", fill="x", expand=True)

        self._import_result = tk.Label(
            bottom, text="", font=FONT_TINY, bg=BG, fg=GREEN
        )
        self._import_result.pack(side="left", padx=16)

        self._btn(bottom, "⬆  Import to Database", self._do_import, side="right")

    # ─── Tab 2: Database records ──────────────────────────────────────────────

    def _build_db_tab(self, parent):
        # Search bar + action buttons
        toolbar = tk.Frame(parent, bg=BG, pady=8)
        toolbar.pack(fill="x", padx=20)

        tk.Label(toolbar, text="Search:", font=FONT_TINY, bg=BG, fg=TEXT_MUTE).pack(side="left")
        self._search_var = tk.StringVar()
        search_entry = tk.Entry(
            toolbar, textvariable=self._search_var,
            font=FONT_MONO, width=28,
            relief="flat", bd=1, highlightthickness=1,
            highlightbackground=BORDER, highlightcolor=GOLD
        )
        search_entry.pack(side="left", padx=(4, 12))
        search_entry.bind("<Return>",    lambda _: self._refresh_db_tab())
        search_entry.bind("<KeyRelease>",lambda _: self._refresh_db_tab())

        self._btn(toolbar, "⟳ Refresh", self._refresh_db_tab, side="left")
        self._btn(
            toolbar, "🗑 Delete Selected", self._delete_selected,
            side="right", bg="#7a3020", fg="#fff5f5"
        )

        self._db_count = tk.Label(toolbar, text="", font=FONT_TINY, bg=BG, fg=TEXT_MUTE)
        self._db_count.pack(side="right", padx=12)

        # Records treeview
        cols = ["serial_number", "product_name", "artisan", "category", "region",
                "registered_on", "imported_from"]
        tree_frame = tk.Frame(parent, bg=BG)
        tree_frame.pack(fill="both", expand=True, padx=20, pady=(0, 16))

        self._db_tree = self._make_treeview(tree_frame, cols)
        self._db_tree.pack(fill="both", expand=True)

    # ─── Reusable widget helpers ──────────────────────────────────────────────

    def _section(self, parent, title):
        return tk.LabelFrame(
            parent, text=f"  {title}  ",
            bg=CARD, fg=GOLD_DARK,
            font=("Georgia", 10, "bold"),
            bd=1, relief="groove",
            labelanchor="nw"
        )

    def _btn(self, parent, label, cmd, side="left", bg=GOLD, fg="#fdf8f2", **kw):
        b = tk.Button(
            parent, text=label, command=cmd,
            font=FONT_BTN, bg=bg, fg=fg,
            relief="flat", padx=12, pady=6,
            activebackground=GOLD_DARK, activeforeground="#fff",
            cursor="hand2", **kw
        )
        b.pack(side=side, padx=4)
        return b

    def _make_treeview(self, parent, cols):
        vsb = ttk.Scrollbar(parent, orient="vertical")
        hsb = ttk.Scrollbar(parent, orient="horizontal")
        tv  = ttk.Treeview(
            parent, columns=cols, show="headings",
            yscrollcommand=vsb.set, xscrollcommand=hsb.set,
            selectmode="extended"
        )
        vsb.configure(command=tv.yview)
        hsb.configure(command=tv.xview)
        vsb.pack(side="right",  fill="y")
        hsb.pack(side="bottom", fill="x")
        tv.pack(side="left", fill="both", expand=True)

        for col in cols:
            label = col.replace("_", " ").title()
            tv.heading(col, text=label, anchor="w")
            tv.column( col, width=140, minwidth=80, anchor="w")

        tv.tag_configure("odd",  background="#fdf8f2")
        tv.tag_configure("even", background="#ffffff")
        return tv

    # ─── Actions ──────────────────────────────────────────────────────────────

    def _browse_file(self):
        path = filedialog.askopenfilename(
            title="Select product Excel or CSV file",
            filetypes=[
                ("Excel files", "*.xlsx *.xls"),
                ("CSV files",   "*.csv"),
                ("All files",   "*.*"),
            ]
        )
        if not path:
            return
        self._current_file = path
        self._file_var.set(os.path.basename(path))
        self._load_preview(path)

    def _load_preview(self, path: str):
        """Read the file, normalise column names, and show the first 50 rows."""
        try:
            if path.lower().endswith(".csv"):
                df = pd.read_csv(path, dtype=str).fillna("")
            else:
                df = pd.read_excel(path, dtype=str).fillna("")
        except Exception as e:
            messagebox.showerror("Read Error", str(e))
            return

        # Normalise column headers using the alias map
        df.columns = [
            COL_MAP.get(c.strip().lower(), c.strip().lower())
            for c in df.columns
        ]

        missing = REQUIRED_COLS - set(df.columns)
        if missing:
            messagebox.showwarning(
                "Missing Columns",
                f"Could not find the required columns: {missing}\n\n"
                f"Columns found: {list(df.columns)}\n\n"
                "Please rename your Excel headers to include at least:\n"
                "  serial_number  and  product_name"
            )

        self._preview_df = df

        # Rebuild the preview tree with whatever columns we have
        cols = list(df.columns)
        self._prev_tree["columns"] = cols
        for col in cols:
            self._prev_tree.heading(col, text=col.replace("_", " ").title(), anchor="w")
            self._prev_tree.column( col, width=130, minwidth=60, anchor="w")

        self._prev_tree.delete(*self._prev_tree.get_children())
        for i, (_, row) in enumerate(df.head(50).iterrows()):
            tag = "odd" if i % 2 else "even"
            self._prev_tree.insert("", "end",
                                   values=[str(row.get(c, "")) for c in cols],
                                   tags=(tag,))

        total = len(df)
        status = (
            f"Loaded {total} row{'s' if total != 1 else ''}."
            + (f" Showing first 50." if total > 50 else "")
            + ("  ⚠ Fix missing columns before importing." if missing
               else "  ✔ Columns look good.")
        )
        self._preview_status.configure(
            text=status,
            fg=RED_DARK if missing else GREEN
        )

    def _do_import(self):
        if self._preview_df is None:
            messagebox.showwarning("No File Loaded", "Please load an Excel or CSV file first.")
            return

        df = self._preview_df
        missing = REQUIRED_COLS - set(df.columns)
        if missing:
            messagebox.showerror("Cannot Import", f"Missing required columns: {missing}")
            return

        rows  = df.to_dict(orient="records")
        fname = os.path.basename(self._current_file or "manual")

        inserted, skipped, errors = db.bulk_insert(rows, imported_from=fname)

        summary = f"✔ Imported: {inserted}  |  ⚠ Skipped: {skipped}"
        self._import_result.configure(
            text=summary,
            fg=GREEN if skipped == 0 else RED_DARK
        )

        detail = f"Import finished.\n\n✔ Inserted: {inserted}\n⚠ Skipped:  {skipped}"
        if errors:
            detail += "\n\nFirst 10 skipped (reason):\n" + "\n".join(errors[:10])

        messagebox.showinfo("Import Result", detail)
        self._refresh_db_tab()

    def _refresh_db_tab(self, *_):
        search = self._search_var.get().strip() if hasattr(self, "_search_var") else ""
        products = db.list_products(search=search)

        self._db_tree.delete(*self._db_tree.get_children())
        cols = ["serial_number", "product_name", "artisan", "category", "region",
                "registered_on", "imported_from"]
        self._db_tree["columns"] = cols
        for col in cols:
            self._db_tree.heading(col, text=col.replace("_", " ").title(), anchor="w")
            self._db_tree.column( col, width=150, minwidth=80, anchor="w")

        for i, p in enumerate(products):
            tag = "odd" if i % 2 else "even"
            self._db_tree.insert("", "end",
                                 iid=p["serial_number"],
                                 values=[p.get(c, "") for c in cols],
                                 tags=(tag,))

        if hasattr(self, "_db_count"):
            self._db_count.configure(text=f"{len(products)} record(s)")

    def _delete_selected(self):
        selected = self._db_tree.selection()
        if not selected:
            messagebox.showwarning("Nothing Selected", "Click rows to select them first.")
            return
        if not messagebox.askyesno(
            "Confirm Deletion",
            f"Permanently delete {len(selected)} product(s) from the database?\n"
            "This cannot be undone."
        ):
            return
        for serial in selected:
            db.delete_product(serial)
        self._refresh_db_tab()
        messagebox.showinfo("Done", f"Deleted {len(selected)} record(s).")


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = ManufacturerApp()
    app.mainloop()
