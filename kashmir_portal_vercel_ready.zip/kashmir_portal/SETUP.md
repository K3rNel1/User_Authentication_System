# Kashmir Authenticity Portal — Setup Guide

## Project Structure

```
kashmir-portal/
├── index.html            ← Customer-facing website (deployed to Vercel)
├── vercel.json           ← Vercel routing config
├── requirements.txt      ← Python dependencies for Vercel
├── database.py           ← Shared Supabase database layer
├── manufacturer_tool.py  ← Desktop app for manufacturers
├── .env.example          ← Credentials template
├── .env                  ← Your actual credentials (never commit this)
└── api/
    ├── verify.py         ← GET /api/verify?serial=KSH-2024-001
    ├── register.py       ← POST /api/register
    └── products.py       ← GET /api/products
```

---

## Step 1 — Supabase Setup

1. Go to https://supabase.com and sign in (or create a free account).

2. Click **New Project**, name it `kashmir-portal`, pick a region close to India
   (e.g. **ap-south-1 Mumbai**), set a strong database password.

3. Once the project is ready, go to:
   **Project Settings → API**
   Copy:
   - **Project URL** → this is your `SUPABASE_URL`
   - **service_role** key (the long secret one) → `SUPABASE_SERVICE_KEY`

4. Go to **SQL Editor → New Query**, paste and run this:

```sql
CREATE TABLE IF NOT EXISTS products (
    serial_number   TEXT PRIMARY KEY,
    product_name    TEXT NOT NULL,
    artisan         TEXT DEFAULT 'Unknown Artisan',
    craft           TEXT DEFAULT '',
    region          TEXT DEFAULT 'Kashmir',
    material        TEXT DEFAULT '',
    gi_tag          TEXT DEFAULT 'GI Tag Certified',
    category        TEXT DEFAULT '',
    registered_on   TEXT DEFAULT '',
    imported_from   TEXT DEFAULT '',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Optional: seed the three demo records
INSERT INTO products (serial_number, product_name, artisan, craft, region, material, gi_tag, category, registered_on)
VALUES
  ('KSH-2024-001', 'Royal Pashmina Shawl',       'Ghulam Mohammad Bhat', 'Kani Weaving',             'Kanihama, Kashmir',  '100% Grade-A Pashmina',       'GI Tag Certified', 'Textiles & Weaving', 'March 2024'),
  ('KSH-2024-002', 'Hand-Knotted Silk Carpet',   'Mushtaq Ahmad Wani',   'Kashmiri Carpet Weaving',  'Srinagar, Kashmir',  'Pure Silk — 900 Knots/sq.in', 'GI Tag Certified', 'Textiles & Weaving', 'January 2024'),
  ('KSH-2024-003', 'Paper Mache Decorative Box', 'Farooq Ahmad Dar',     'Paper Mache (Kar-i-Qalam)','Old City, Srinagar', 'Hand-painted Paper Mache',    'GI Tag Certified', 'Painting & Art',     'May 2024')
ON CONFLICT (serial_number) DO NOTHING;
```

---

## Step 2 — Local .env File

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
```

Edit `.env`:
```
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_KEY=eyJhbGc...   ← the publishable key from Project Settings → API
```

---

## Step 3 — Test the Database Connection

```bash
pip install supabase python-dotenv
python database.py
```

You should see something like:
```
Connection OK — 3 product(s) in database.
Most recent: KSH-2024-003 — Paper Mache Decorative Box
```

---

## Step 4 — Run the Manufacturer Tool

```bash
pip install pandas openpyxl
python manufacturer_tool.py
```

The desktop GUI will open. Use **Tab ①** to import an Excel file,
and **Tab ②** to browse and delete records.

---

## Step 5 — Deploy to Vercel

### Install Vercel CLI (once)
```bash
npm install -g vercel
```

### Deploy
```bash
cd kashmir-portal
vercel
```

Follow the prompts:
- **Set up and deploy?** → Yes
- **Which scope?** → your account
- **Link to existing project?** → No (first time)
- **Project name** → kashmir-portal (or whatever you like)
- **In which directory is your code?** → ./ (just press Enter)

### Add your environment variables to Vercel
After deploying, run:
```bash
vercel env add SUPABASE_URL
vercel env add SUPABASE_KEY
```
Paste each value when prompted. Then redeploy:
```bash
vercel --prod
```

Or add them through the Vercel dashboard:
**Project → Settings → Environment Variables**

### Your site will be live at:
```
https://kashmir-portal.vercel.app
```
(or whatever name Vercel assigned)

---

## How the Three Parts Connect

```
Manufacturer's laptop
  └─ manufacturer_tool.py
       └─ database.py ──────────────→ Supabase (cloud database)
                                            ↑
Customer's browser                          │
  └─ index.html (on Vercel)                 │
       └─ /api/verify?serial=... ───────────┘
            └─ api/verify.py
                 └─ database.py
```

The database is the single source of truth.
Manufacturers write to it; customers read from it through the API.

---

## Common Issues

**"Missing Supabase credentials"** when running manufacturer_tool.py
→ Make sure `.env` exists in the same folder and has both keys.

**Products not showing after import**
→ Check the Supabase dashboard: Table Editor → products.
  If the table is empty, re-run the SQL from Step 1.

**Vercel deploy fails**
→ Make sure `requirements.txt` is in the root of the project folder.
  Also confirm the environment variables are set in Vercel's dashboard.

**CORS errors in the browser**
→ The headers are already set in `vercel.json`. If you test locally with
  Flask or another server, make sure CORS is enabled there too.
