"""
database.py — Kashmir Authenticity Portal
==========================================
Supabase (PostgreSQL) database layer.
Used by the Vercel API handlers and the local manufacturer tool.

SUPABASE INTEGRATION:
    This file is ready for Supabase. To activate:
    1. Set SUPABASE_URL and SUPABASE_KEY in your .env (local)
       or in Vercel → Project Settings → Environment Variables (production).
    2. Run the SQL schema in your Supabase SQL Editor (see SETUP.md).
    3. Uncomment the Supabase client block below and remove the stub functions.

Setup:
    pip install supabase python-dotenv flask
    Add your credentials to .env (see .env.example)
"""

import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "")

# ---------------------------------------------------------------------------
# Lazy Supabase client — only raises if you actually call a DB function
# without credentials. Safe to import in Vercel cold starts.
# ---------------------------------------------------------------------------
_client = None


def get_client():
    """
    Return a cached Supabase client.

    # ── SUPABASE INTEGRATION POINT ──────────────────────────────────────────
    # When you are ready to connect Supabase, ensure SUPABASE_URL and
    # SUPABASE_KEY are set, then uncomment the block below:
    #
    # from supabase import create_client
    # global _client
    # if _client is None:
    #     if not SUPABASE_URL or not SUPABASE_KEY:
    #         raise EnvironmentError(
    #             "Missing Supabase credentials. "
    #             "Set SUPABASE_URL and SUPABASE_KEY in your .env file."
    #         )
    #     _client = create_client(SUPABASE_URL, SUPABASE_KEY)
    # return _client
    # ────────────────────────────────────────────────────────────────────────
    """
    global _client
    if _client is None:
        if not SUPABASE_URL or not SUPABASE_KEY:
            raise EnvironmentError(
                "Missing Supabase credentials.\n"
                "Set SUPABASE_URL and SUPABASE_KEY in your .env file.\n"
                "See .env.example for reference."
            )
        # ── SUPABASE INTEGRATION POINT ──
        # Replace this import with the real supabase library when ready:
        from supabase import create_client
        _client = create_client(SUPABASE_URL, SUPABASE_KEY)
    return _client


# ---------------------------------------------------------------------------
# SQL schema reference (run once in Supabase SQL Editor)
# ---------------------------------------------------------------------------
# CREATE TABLE IF NOT EXISTS products (
#     serial_number   TEXT PRIMARY KEY,
#     product_name    TEXT NOT NULL,
#     artisan         TEXT DEFAULT 'Unknown Artisan',
#     craft           TEXT DEFAULT '',
#     region          TEXT DEFAULT 'Kashmir',
#     material        TEXT DEFAULT '',
#     gi_tag          TEXT DEFAULT 'GI Tag Certified',
#     category        TEXT DEFAULT '',
#     registered_on   TEXT DEFAULT '',
#     imported_from   TEXT DEFAULT '',
#     created_at      TIMESTAMPTZ DEFAULT NOW()
# );
#
# -- Optional seed data:
# INSERT INTO products (serial_number, product_name, artisan, craft, region,
#                       material, gi_tag, category, registered_on)
# VALUES
#   ('KSH-2024-001','Royal Pashmina Shawl','Ghulam Mohammad Bhat',
#    'Kani Weaving','Kanihama, Kashmir','100% Grade-A Pashmina',
#    'GI Tag Certified','Textiles & Weaving','March 2024'),
#   ('KSH-2024-002','Hand-Knotted Silk Carpet','Mushtaq Ahmad Wani',
#    'Kashmiri Carpet Weaving','Srinagar, Kashmir',
#    'Pure Silk — 900 Knots/sq.in','GI Tag Certified',
#    'Textiles & Weaving','January 2024'),
#   ('KSH-2024-003','Paper Mache Decorative Box','Farooq Ahmad Dar',
#    'Paper Mache (Kar-i-Qalam)','Old City, Srinagar',
#    'Hand-painted Paper Mache','GI Tag Certified','Painting & Art','May 2024')
# ON CONFLICT (serial_number) DO NOTHING;


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_product(serial: str) -> dict | None:
    """Look up a single product by serial number. Returns None if not found."""
    result = (
        get_client()
        .table("products")
        .select("*")
        .eq("serial_number", serial.upper())
        .maybe_single()
        .execute()
    )
    return result.data  # dict or None


def list_products(search: str = "") -> list[dict]:
    """
    Return all products, newest first.
    Pass a search string to filter by serial, name, artisan, category, or region.
    """
    query = get_client().table("products").select("*").order("created_at", desc=True)

    if search:
        term = f"%{search.lower()}%"
        query = query.or_(
            f"serial_number.ilike.{term},"
            f"product_name.ilike.{term},"
            f"artisan.ilike.{term},"
            f"category.ilike.{term},"
            f"region.ilike.{term}"
        )

    return query.execute().data or []


def insert_product(data: dict, imported_from: str = "") -> tuple[bool, str]:
    """
    Insert a single product record.
    Returns (success, serial_or_error_message).
    """
    serial = (data.get("serial_number") or data.get("serialNumber") or "").strip().upper()
    name   = (data.get("product_name")  or data.get("productName")  or "").strip()

    if not serial:
        return False, "Missing serial number"
    if not name:
        return False, "Missing product name"

    registered_on = (
        data.get("registered_on")
        or data.get("registeredOn")
        or datetime.now().strftime("%B %Y")
    )

    record = {
        "serial_number": serial,
        "product_name":  name,
        "artisan":       data.get("artisan",  "Unknown Artisan"),
        "craft":         data.get("craft",    ""),
        "region":        data.get("region",   "Kashmir"),
        "material":      data.get("material", ""),
        "gi_tag":        data.get("gi_tag",   "GI Tag Certified"),
        "category":      data.get("category", ""),
        "registered_on": registered_on,
        "imported_from": imported_from,
    }

    try:
        get_client().table("products").insert(record).execute()
        return True, serial
    except Exception as e:
        msg = str(e)
        if "duplicate" in msg.lower() or "unique" in msg.lower():
            return False, f"Serial '{serial}' already exists"
        return False, msg


def delete_product(serial: str) -> bool:
    """Delete a product by serial number. Returns True if something was deleted."""
    result = (
        get_client()
        .table("products")
        .delete()
        .eq("serial_number", serial.upper())
        .execute()
    )
    return bool(result.data)


def bulk_insert(rows: list[dict], imported_from: str = "") -> tuple[int, int, list[str]]:
    """
    Insert many rows at once.
    Returns (inserted_count, skipped_count, list_of_error_messages).
    """
    inserted, skipped, errors = 0, 0, []
    for row in rows:
        ok, msg = insert_product(row, imported_from)
        if ok:
            inserted += 1
        else:
            skipped += 1
            errors.append(msg)
    return inserted, skipped, errors


# ---------------------------------------------------------------------------
# Quick connection sanity-check — run: python database.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    products = list_products()
    print(f"Connection OK — {len(products)} product(s) in database.")
    if products:
        print("Most recent:", products[0]["serial_number"], "—", products[0]["product_name"])
