# Kashmir Authenticity Portal

A product authentication system for genuine Kashmiri handicrafts.
Manufacturers register products; customers scan/verify serial numbers via the web portal.

---

## Project Structure

```
kashmir-portal/
├── main.py                ← PRIMARY ENTRY POINT (Flask app + Vercel handler)
├── vercel.json            ← Vercel routing & build config
├── requirements.txt       ← Python dependencies
├── database.py            ← Shared Supabase database layer
├── manufacturer_tool.py   ← Desktop GUI for bulk product import (local only)
├── index.html             ← Customer-facing frontend (static)
├── .env.example           ← Credentials template (copy → .env)
├── .gitignore
└── api/
    ├── __init__.py
    ├── verify.py          ← GET  /api/verify?serial=KSH-2024-001
    ├── register.py        ← POST /api/register
    └── products.py        ← GET  /api/products[?q=search]
```

---

## How to Run Locally

### 1. Clone and install dependencies

```bash
git clone <your-repo-url>
cd kashmir-portal

python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Set up environment variables

```bash
cp .env.example .env
# Edit .env and fill in SUPABASE_URL and SUPABASE_KEY
```

### 3. Start the development server

```bash
python main.py
```

The app runs at **http://localhost:5000**

API endpoints available locally:
- `GET  http://localhost:5000/api/verify?serial=KSH-2024-001`
- `POST http://localhost:5000/api/register`
- `GET  http://localhost:5000/api/products`

### 4. (Optional) Run the manufacturer desktop tool

```bash
pip install pandas openpyxl
python manufacturer_tool.py
```

Requires a connected Supabase database and a valid `.env` file.

---

## How to Deploy on Vercel

### Prerequisites
- A [Vercel account](https://vercel.com)
- The [Vercel CLI](https://vercel.com/docs/cli): `npm install -g vercel`

### Deploy

```bash
vercel
```

Follow the prompts (first-time setup). For production:

```bash
vercel --prod
```

### Add environment variables to Vercel

Either via CLI:

```bash
vercel env add SUPABASE_URL
vercel env add SUPABASE_KEY
```

Or via the Vercel Dashboard:
**Project → Settings → Environment Variables**

Then redeploy:

```bash
vercel --prod
```

### How Vercel routes requests

```
vercel.json
  /api/verify    →  main.py  →  api/verify.py
  /api/register  →  main.py  →  api/register.py
  /api/products  →  main.py  →  api/products.py
  /*             →  index.html  (static)
```

---

## Where Supabase Integration Can Later Be Added

All database interaction is isolated to **`database.py`**.

Each file that touches the database has a comment marking the exact location:

```
# ── SUPABASE INTEGRATION POINT ──
```

### Checklist to activate Supabase

1. **`database.py` → `get_client()`**
   Uncomment the `create_client` block and remove the placeholder stub.

2. **`.env`**
   Fill in `SUPABASE_URL` and `SUPABASE_KEY` from your Supabase project settings.

3. **Vercel environment variables**
   Add the same two keys in Vercel → Project Settings → Environment Variables.

4. **Run the SQL schema** in Supabase SQL Editor (full schema in `database.py` comments and `SETUP.md`).

5. **Test locally**:
   ```bash
   python database.py
   # Expected: Connection OK — N product(s) in database.
   ```

---

## Architecture Overview

```
Manufacturer's laptop
  └─ manufacturer_tool.py  (desktop GUI)
       └─ database.py  ──────────────────────→  Supabase (cloud database)
                                                        ↑
Customer's browser                                      │
  └─ index.html  (on Vercel CDN)                        │
       └─ /api/verify?serial=...  ─────────────────────┘
            └─ api/verify.py  (via main.py)
                 └─ database.py
```

The database is the single source of truth.
Manufacturers write to it via the desktop tool; customers read from it through the API.

---

## Common Issues

| Problem | Fix |
|---|---|
| `Missing Supabase credentials` | Ensure `.env` exists with both keys filled in |
| Vercel deploy fails | Check `requirements.txt` is in project root; confirm env vars are set in Vercel dashboard |
| CORS errors in browser | Headers are set in `vercel.json` and `main.py`; test with a proper HTTP client locally |
| `ModuleNotFoundError: flask` | Run `pip install -r requirements.txt` |
| Products not showing after import | Check Supabase Table Editor → products; re-run the SQL schema if the table is missing |
