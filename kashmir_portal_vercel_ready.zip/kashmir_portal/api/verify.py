"""
api/verify.py — Kashmir Authenticity Portal
============================================
GET /api/verify?serial=KSH-2024-001

Returns full product details if the serial number is found,
or {"found": false} if it is not registered.
"""

import sys
import os

# Ensure the project root is on sys.path so database.py is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import jsonify
import database as db


def handler(request):
    """Flask-compatible handler. Called from main.py."""

    # Handle CORS preflight
    if request.method == "OPTIONS":
        return "", 200

    serial = (request.args.get("serial") or "").strip().upper()

    if not serial:
        return jsonify({"error": "serial parameter is required"}), 400

    try:
        product = db.get_product(serial)
    except EnvironmentError as e:
        # ── SUPABASE INTEGRATION POINT ──────────────────────────────────────
        # This error is raised when SUPABASE_URL / SUPABASE_KEY are not set.
        # Set them in .env (local) or Vercel Environment Variables (production).
        # ────────────────────────────────────────────────────────────────────
        return jsonify({"error": str(e)}), 503

    if product:
        return jsonify({
            "found":        True,
            "serialNumber": product["serial_number"],
            "productName":  product["product_name"],
            "artisan":      product.get("artisan",       ""),
            "craft":        product.get("craft",         ""),
            "region":       product.get("region",        ""),
            "material":     product.get("material",      ""),
            "gi_tag":       product.get("gi_tag",        "GI Tag Certified"),
            "registeredOn": product.get("registered_on", ""),
            "category":     product.get("category",      ""),
        })

    return jsonify({"found": False})
