"""
api/products.py — Kashmir Authenticity Portal
==============================================
GET /api/products          → list all products (newest first)
GET /api/products?q=shawl  → search by name, serial, artisan, category, or region
"""

import sys
import os

# Ensure the project root is on sys.path so database.py is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import jsonify
import database as db


def handler(request):
    """Flask-compatible handler. Called from main.py."""

    # Handle CORS preflight
    if request.method == "OPTIONS":
        return "", 200

    search   = (request.args.get("q") or "").strip()

    try:
        products = db.list_products(search=search)
    except EnvironmentError as e:
        # ── SUPABASE INTEGRATION POINT ──────────────────────────────────────
        # Raised when SUPABASE_URL / SUPABASE_KEY are not set.
        # Set them in .env (local) or Vercel Environment Variables (production).
        # ────────────────────────────────────────────────────────────────────
        return jsonify({"error": str(e)}), 503

    return jsonify({"products": products, "total": len(products)})
