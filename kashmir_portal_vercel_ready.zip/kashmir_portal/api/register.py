"""
api/register.py — Kashmir Authenticity Portal
==============================================
POST /api/register
Body (JSON): { productName, category, artisan, craft, region, material, manualSerial? }

Registers a new product and returns the assigned serial number.
"""

import sys
import os
import random
import string
from datetime import datetime

# Ensure the project root is on sys.path so database.py is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import jsonify
import database as db


def generate_serial(category: str = "KSH") -> str:
    """Generate a unique serial number like TXT-2025-A3B9F2."""
    prefix = (category or "KSH")[:3].upper().replace(" ", "")
    year   = datetime.now().year
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"{prefix}-{year}-{suffix}"


def handler(request):
    """Flask-compatible handler. Called from main.py."""

    # Handle CORS preflight
    if request.method == "OPTIONS":
        return "", 200

    try:
        data = request.get_json(force=True, silent=True)
    except Exception:
        return jsonify({"error": "Request body must be valid JSON"}), 400

    if not data:
        return jsonify({"error": "No data received"}), 400

    product_name  = (data.get("productName",  "") or "").strip()
    category      = (data.get("category",     "") or "").strip()
    manual_serial = (data.get("manualSerial", "") or "").strip()

    if not product_name or not category:
        return jsonify({"error": "productName and category are required"}), 400

    serial = (manual_serial or generate_serial(category)).upper()

    record = {
        "serial_number": serial,
        "product_name":  product_name,
        "category":      category,
        "artisan":       data.get("artisan",  "Unknown Artisan"),
        "craft":         data.get("craft",    category),
        "region":        data.get("region",   "Kashmir"),
        "material":      data.get("material", ""),
        "gi_tag":        "GI Tag Certified",
        "registered_on": datetime.now().strftime("%B %Y"),
    }

    try:
        ok, msg = db.insert_product(record, imported_from="API")
    except EnvironmentError as e:
        # ── SUPABASE INTEGRATION POINT ──────────────────────────────────────
        # Raised when SUPABASE_URL / SUPABASE_KEY are not set.
        # Set them in .env (local) or Vercel Environment Variables (production).
        # ────────────────────────────────────────────────────────────────────
        return jsonify({"error": str(e)}), 503

    if not ok:
        status = 409 if "already exists" in msg else 400
        return jsonify({"error": msg}), status

    return jsonify({"success": True, "serialNumber": serial})
