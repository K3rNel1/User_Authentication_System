"""
main.py — Kashmir Authenticity Portal
======================================
Primary entry point for the application.

- On Vercel: this file is detected as the Python entry point and
  serves the Flask app via the Vercel Python runtime.
- Locally: run with `python main.py` to start the development server.

Vercel routes API requests here via vercel.json:
  /api/verify    → handled by api/verify.py
  /api/register  → handled by api/register.py
  /api/products  → handled by api/products.py
  /*             → served from index.html (static)
"""

from flask import Flask, jsonify, request, send_from_directory
import os

# ---------------------------------------------------------------------------
# Flask app — also imported by Vercel's Python runtime
# ---------------------------------------------------------------------------
app = Flask(__name__, static_folder=".", static_url_path="")


# ---------------------------------------------------------------------------
# Serve the frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(".", "index.html")


# ---------------------------------------------------------------------------
# API routes — delegated to the api/ modules
# ---------------------------------------------------------------------------
from api.verify import handler as verify_handler
from api.register import handler as register_handler
from api.products import handler as products_handler


@app.route("/api/verify", methods=["GET", "OPTIONS"])
def verify():
    return verify_handler(request)


@app.route("/api/register", methods=["POST", "OPTIONS"])
def register():
    return register_handler(request)


@app.route("/api/products", methods=["GET", "OPTIONS"])
def products():
    return products_handler(request)


# ---------------------------------------------------------------------------
# CORS headers on every response
# ---------------------------------------------------------------------------
@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


# ---------------------------------------------------------------------------
# Local development server
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Kashmir Authenticity Portal — running at http://localhost:{port}")
    app.run(debug=True, port=port)
